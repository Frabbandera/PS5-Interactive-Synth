/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
FlangerPluginAudioProcessorEditor::FlangerPluginAudioProcessorEditor (FlangerPluginAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    const int numParams = paramIDs.size();
    sliders.ensureStorageAllocated(numParams);
    labels.ensureStorageAllocated(numParams);
    attachments.ensureStorageAllocated(numParams);

    for (int i = 0; i < numParams; ++i)
    {
        auto* slider = new juce::Slider();
        auto* label = new juce::Label();

        setupSliderWithLabel(*slider, *label, paramNames[i]);

        addAndMakeVisible(slider);
        addAndMakeVisible(label);

        sliders.add(slider);
        labels.add(label);
        attachments.add(new Attachment(audioProcessor.getValueTreeState(), paramIDs[i], *slider));
    }

    setSize(400, 200);
}

FlangerPluginAudioProcessorEditor::~FlangerPluginAudioProcessorEditor()
{
}

//==============================================================================
void FlangerPluginAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll(juce::Colour::fromRGB(200, 255, 200)); // verde pastello
}

void FlangerPluginAudioProcessorEditor::resized()
{
    const int padding = 10;
    const int knobSize = 60;
    const int labelHeight = 20;
    const int spacingX = 10;
    const int spacingY = 20;

    const int knobsPerRow = 3;

    for (int i = 0; i < sliders.size(); ++i)
    {
        int row = i / knobsPerRow;
        int col = i % knobsPerRow;

        int x = padding + col * (knobSize + spacingX);
        int y = padding + row * (knobSize + labelHeight + spacingY);

        sliders[i]->setBounds(x, y, knobSize, knobSize);
        labels[i]->setBounds(x, y + knobSize, knobSize, labelHeight);
    }
}

void FlangerPluginAudioProcessorEditor::setupSliderWithLabel(juce::Slider& slider, juce::Label& label, const juce::String& name)
{
    slider.setSliderStyle(juce::Slider::RotaryVerticalDrag);
    slider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 50, 15);

    // colori knob
    slider.setColour(juce::Slider::rotarySliderFillColourId, juce::Colours::mediumseagreen);
    slider.setColour(juce::Slider::rotarySliderOutlineColourId, juce::Colours::darkgreen);
    slider.setColour(juce::Slider::thumbColourId, juce::Colours::darkgreen);

    label.setText(name, juce::dontSendNotification);
    label.setJustificationType(juce::Justification::centredTop);
    label.attachToComponent(&slider, false);
}
