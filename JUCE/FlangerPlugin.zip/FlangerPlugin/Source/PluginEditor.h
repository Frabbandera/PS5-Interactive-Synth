/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class FlangerPluginAudioProcessorEditor  : public juce::AudioProcessorEditor
{
public:
    FlangerPluginAudioProcessorEditor (FlangerPluginAudioProcessor&);
    ~FlangerPluginAudioProcessorEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    FlangerPluginAudioProcessor& audioProcessor;

    using Slider = juce::Slider;
    using Attachment = juce::AudioProcessorValueTreeState::SliderAttachment;

    juce::OwnedArray<Slider> sliders;
    juce::OwnedArray<juce::Label> labels;
    juce::OwnedArray<Attachment> attachments;

    const juce::StringArray paramIDs{ "dryWet", "depth", "rate", "feedback", "amplitude" };
    const juce::StringArray paramNames{ "Dry/Wet", "Depth", "Rate", "Feedback", "Amplitude" };

    void setupSliderWithLabel(Slider& slider, juce::Label& label, const juce::String& name);

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (FlangerPluginAudioProcessorEditor)
};
