/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
FlangerPluginAudioProcessor::FlangerPluginAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       )
#else 
    : AudioProcessor()
#endif
    , parameters(*this, nullptr, juce::Identifier("FlangerParams"), createParameterLayout())
{
}

FlangerPluginAudioProcessor::~FlangerPluginAudioProcessor()
{
}

//==============================================================================
const juce::String FlangerPluginAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool FlangerPluginAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool FlangerPluginAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool FlangerPluginAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double FlangerPluginAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int FlangerPluginAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int FlangerPluginAudioProcessor::getCurrentProgram()
{
    return 0;
}

void FlangerPluginAudioProcessor::setCurrentProgram (int index)
{
}

const juce::String FlangerPluginAudioProcessor::getProgramName (int index)
{
    return {};
}

void FlangerPluginAudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void FlangerPluginAudioProcessor::prepareToPlay(double sr, int samplesPerBlock)
{
    sampleRate = sr;

    int maxDelaySamples = (int)(0.01 * sampleRate) + 1; // 10 ms

    delayBuffer.resize(getTotalNumInputChannels());
    writePosition.resize(getTotalNumInputChannels());

    for (int ch = 0; ch < getTotalNumInputChannels(); ++ch)
    {
        delayBuffer[ch].assign(maxDelaySamples, 0.0f);
        writePosition[ch] = 0;
    }

    phase = 0.0f;
}

void FlangerPluginAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool FlangerPluginAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void FlangerPluginAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numChannels = buffer.getNumChannels();
    const int numSamples = buffer.getNumSamples();

    lfoFrequency = parameters.getRawParameterValue("rate")->load();
    lfoDepth = parameters.getRawParameterValue("depth")->load();
    feedback = parameters.getRawParameterValue("feedback")->load();
    dryWet = parameters.getRawParameterValue("dryWet")->load();
    lfoAmplitude = parameters.getRawParameterValue("amplitude")->load();

    float twoPi = juce::MathConstants<float>::twoPi;
    float increment = twoPi * lfoFrequency / (float)sampleRate;

    for (int ch = 0; ch < numChannels; ++ch)
    {
        float* channelData = buffer.getWritePointer(ch);
        auto& delayLine = delayBuffer[ch];
        auto& wp = writePosition[ch];
        int delayBufferSize = (int)delayLine.size();

        for (int i = 0; i < numSamples; ++i)
        {
            float lfoValue = std::sin(phase) * lfoAmplitude;
            float currentDelay = (0.005f + 0.005f * lfoDepth * lfoValue); // 5-10ms range

            float delayInSamples = currentDelay * (float)sampleRate;

            int readPos = (int)(wp - delayInSamples + delayBufferSize) % delayBufferSize;
            int nextPos = (readPos + 1) % delayBufferSize;
            float frac = delayInSamples - std::floor(delayInSamples);

            float delayedSample = juce::jmap(frac, delayLine[readPos], delayLine[nextPos]);

            float inputSample = channelData[i];
            float outputSample = inputSample * (1.0f - dryWet) + delayedSample * dryWet;

            delayLine[wp] = inputSample + delayedSample * feedback;

            channelData[i] = outputSample;

            wp = (wp + 1) % delayBufferSize;

            if (ch == 0) // solo una volta per campione
                phase += increment;
        }
    }

    if (phase >= juce::MathConstants<float>::twoPi)
        phase -= juce::MathConstants<float>::twoPi;
}

//==============================================================================
bool FlangerPluginAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* FlangerPluginAudioProcessor::createEditor()
{
    return new FlangerPluginAudioProcessorEditor (*this);
}

//==============================================================================
void FlangerPluginAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
}

void FlangerPluginAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new FlangerPluginAudioProcessor();
}

//==============================================================================

juce::AudioProcessorValueTreeState::ParameterLayout FlangerPluginAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterFloat>("dryWet", "Dry/Wet", 0.0f, 1.0f, 0.5f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("depth", "Depth", 0.0f, 1.0f, 0.5f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("rate", "Rate", 0.01f, 5.0f, 0.25f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("feedback", "Feedback", -0.95f, 0.95f, 0.5f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>("amplitude", "Amplitude", 0.0f, 1.0f, 1.0f));

    return { params.begin(), params.end() };
}
